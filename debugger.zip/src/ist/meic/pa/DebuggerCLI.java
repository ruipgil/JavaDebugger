package ist.meic.pa;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;

public class DebuggerCLI {
	public static void main(String[] args) {
		String programName = args[0];
		String[] restArgs = Arrays.copyOfRange(args, 1, args.length);
		
		ClassPool pool = ClassPool.getDefault();
		CtClass ctClass;
		try {
			ctClass = pool.get(programName);
			Class<?> rtClass = ctClass.toClass();
			
			//memoize(ctClass, ctClass.getDeclaredMethod(args[1]));
			
			/*Method main = rtClass.getMethod("main", args.getClass());
			main.invoke(null, new Object[] { restArgs });*/
			
			// get methods of a class
			//   add addCatch method to each one
			// getDeclaredClasses
			//   repeat if it's not primitive

		} catch (NotFoundException e) {
			//System.err.println(programName+" not found!");
			e.printStackTrace();
		} catch (CannotCompileException e) {
			//System.err.println(programName+" could not compile!");
			e.printStackTrace();
		} catch (SecurityException e) {
			//System.err.println("Security exception!");
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			System.err.println(programName+" doesn't contain a main!");
		} catch (IllegalArgumentException e) {
			//System.err.println("Illegal argument!");
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			System.err.println("Illegal access!");
		} catch (InvocationTargetException e) {
			System.err.println("Invocation target exception!");
		}

	}
}
